# 🚀 GigFlow – Smart Leads Dashboard

A production-ready, full-stack Lead Management Dashboard built with the MERN stack, TypeScript, TailwindCSS, and Docker.

---

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Quick Start (Docker)](#quick-start-docker)
- [Manual Setup](#manual-setup)
- [Environment Variables](#environment-variables)
- [Seed Data](#seed-data)
- [API Documentation](#api-documentation)
- [User Roles](#user-roles)
- [Deployment](#deployment)
- [Demo Script](#demo-walkthrough-script)

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🔐 JWT Authentication | Register, Login, Protected routes |
| 👥 Role-Based Access Control | Admin (full CRUD) vs Sales (view/update assigned) |
| 📋 Leads CRUD | Create, Read, Update, Delete with validation |
| 🔍 Advanced Filtering | Filter by Status, Source; search by name/email |
| ⏳ Debounced Search | 400ms debounce on search input |
| 📄 Backend Pagination | Skip/limit with metadata (page, total, hasNext) |
| 📤 CSV Export | Export filtered leads with one click |
| 🌙 Dark Mode | System-aware, toggle-able dark mode |
| 🐳 Docker | Full Docker Compose setup |
| 📱 Responsive | Mobile-first Tailwind design |
| ⚡ Rate Limiting | Express rate limiting for auth and API routes |

---

## 🛠 Tech Stack

### Frontend
- **React 18** + **TypeScript**
- **TailwindCSS** – Utility-first styling
- **React Router v6** – Client-side routing
- **Zustand** – Lightweight state management
- **React Hook Form** + **Zod** – Form handling and validation
- **Axios** – HTTP client with interceptors
- **Lucide React** – Icons

### Backend
- **Node.js** + **Express.js** + **TypeScript**
- **MongoDB** + **Mongoose** – Database and ODM
- **JWT** – Stateless authentication
- **bcryptjs** – Password hashing
- **express-validator** – Request validation
- **Helmet** – Security headers
- **express-rate-limit** – Rate limiting

---

## 📁 Project Structure

```
gigflow-smart-leads-dashboard/
├── frontend/
│   ├── src/
│   │   ├── api/              # Axios instance + API service layers
│   │   │   ├── axios.ts      # Configured Axios with interceptors
│   │   │   ├── auth.api.ts   # Auth API calls
│   │   │   └── leads.api.ts  # Leads API calls
│   │   ├── components/
│   │   │   ├── common/       # Button, Input, Modal, Pagination, Badge, Spinner, EmptyState
│   │   │   ├── layout/       # Sidebar, Header, Layout
│   │   │   └── leads/        # LeadTable, LeadFilters, LeadForm, LeadDetailModal
│   │   ├── context/
│   │   │   ├── authStore.ts  # Zustand auth store
│   │   │   └── ThemeContext.tsx
│   │   ├── hooks/
│   │   │   ├── useDebounce.ts
│   │   │   └── useLeads.ts
│   │   ├── pages/            # LoginPage, RegisterPage, DashboardPage, LeadsPage
│   │   ├── routes/           # AppRouter, ProtectedRoute
│   │   ├── types/            # TypeScript interfaces
│   │   └── utils/            # formatters, csv utils
│   ├── Dockerfile
│   ├── nginx.conf
│   ├── tailwind.config.js
│   ├── vite.config.ts
│   └── package.json
│
├── backend/
│   ├── src/
│   │   ├── config/           # env.ts, db.ts
│   │   ├── controllers/      # auth.controller.ts, leads.controller.ts
│   │   ├── middleware/       # auth, rbac, error middleware
│   │   ├── models/           # User.model.ts, Lead.model.ts
│   │   ├── routes/           # auth.routes.ts, leads.routes.ts
│   │   ├── scripts/          # seed.ts
│   │   ├── services/         # auth.service.ts, leads.service.ts
│   │   ├── types/            # auth.types.ts, lead.types.ts
│   │   ├── utils/            # response.util.ts, jwt.util.ts
│   │   ├── validators/       # auth.validator.ts, lead.validator.ts
│   │   └── app.ts            # Express entry point
│   ├── Dockerfile
│   ├── tsconfig.json
│   └── package.json
│
├── docker-compose.yml
├── .env.example
└── README.md
```

---

## 🐳 Quick Start (Docker)

The fastest way to run the entire stack:

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/gigflow-smart-leads-dashboard.git
cd gigflow-smart-leads-dashboard

# 2. Set up environment variables
cp .env.example .env
# Edit .env with your values (especially JWT_SECRET)

# 3. Build and start all services
docker compose up --build -d

# 4. Seed the database (first time only)
docker exec gigflow_backend node dist/scripts/seed.js

# 5. Open the app
# Frontend: http://localhost:3000
# Backend:  http://localhost:5000
# API docs: http://localhost:5000/health
```

---

## 🔧 Manual Setup

### Prerequisites
- Node.js v20+
- MongoDB (local or Atlas)
- npm or yarn

### Backend

```bash
cd backend
npm install

# Set up environment
cp .env.example .env
# Edit .env — set MONGODB_URI and JWT_SECRET at minimum

# Start development server
npm run dev

# Seed data
npm run seed

# Build for production
npm run build
npm start
```

### Frontend

```bash
cd frontend
npm install

# Set up environment
cp .env.example .env
# Edit VITE_API_BASE_URL to point to your backend

# Start development server
npm run dev

# Build for production
npm run build
npm run preview
```

---

## 🔑 Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Backend server port | `5000` |
| `NODE_ENV` | Environment | `development` |
| `MONGODB_URI` | MongoDB connection string | `mongodb://localhost:27017/gigflow` |
| `JWT_SECRET` | JWT signing secret (min 32 chars) | *required* |
| `JWT_EXPIRES_IN` | Token expiry | `7d` |
| `BCRYPT_SALT_ROUNDS` | Password hash rounds | `12` |
| `CORS_ORIGIN` | Allowed frontend origin | `http://localhost:5173` |
| `VITE_API_BASE_URL` | Backend API URL (frontend) | `http://localhost:5000/api` |

---

## 🌱 Seed Data

Running the seed script creates:

**Users:**
| Name | Email | Password | Role |
|------|-------|----------|------|
| Admin User | admin@gigflow.com | password123 | admin |
| Sarah Johnson | sarah@gigflow.com | password123 | sales |
| Mike Chen | mike@gigflow.com | password123 | sales |

**Leads:** 15 sample leads across all statuses and sources, assigned to sales users.

```bash
# With npm
npm run seed

# With Docker
docker exec gigflow_backend node dist/scripts/seed.js
```

---

## 📖 API Documentation

### Base URL
```
http://localhost:5000/api
```

### Authentication

#### POST /auth/register
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password1",
  "role": "sales"
}
```

#### POST /auth/login
```json
{
  "email": "admin@gigflow.com",
  "password": "password123"
}
```
**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": { "id": "...", "name": "Admin User", "email": "admin@gigflow.com", "role": "admin" },
    "token": "eyJhbGciOiJIUzI1NiIs..."
  }
}
```

#### GET /auth/me *(requires Bearer token)*
Returns the authenticated user's profile.

---

### Leads

All lead routes require `Authorization: Bearer <token>` header.

#### GET /leads
```
GET /leads?status=Qualified&source=Instagram&search=Rahul&sort=latest&page=1&limit=10
```
**Query Parameters:**
| Param | Type | Values |
|-------|------|--------|
| `status` | string | New, Contacted, Qualified, Lost |
| `source` | string | Website, Instagram, Referral |
| `search` | string | Name or email substring |
| `sort` | string | latest, oldest |
| `page` | number | Positive integer |
| `limit` | number | 1–100 (default: 10) |

**Response:**
```json
{
  "success": true,
  "data": [...],
  "meta": {
    "total": 45,
    "page": 1,
    "limit": 10,
    "totalPages": 5,
    "hasNextPage": true,
    "hasPrevPage": false
  }
}
```

#### POST /leads *(admin only)*
```json
{
  "name": "Rahul Sharma",
  "email": "rahul@techcorp.com",
  "phone": "+91-9876543210",
  "company": "TechCorp",
  "status": "New",
  "source": "Instagram",
  "notes": "Interested in enterprise plan"
}
```

#### GET /leads/:id
Returns a single lead by ID.

#### PATCH /leads/:id
Update any field of a lead. Sales users can only update their assigned leads.

#### DELETE /leads/:id *(admin only)*
Permanently deletes a lead.

#### GET /leads/export
Downloads a CSV file of leads with the current filters applied.

#### GET /leads/stats
Returns dashboard statistics:
```json
{
  "success": true,
  "data": {
    "total": 15,
    "byStatus": { "New": 5, "Contacted": 3, "Qualified": 4, "Lost": 3 },
    "bySource": { "Website": 6, "Instagram": 5, "Referral": 4 },
    "recentLeads": [...]
  }
}
```

---

## 👥 User Roles

### Admin
- Full CRUD on all leads
- View all leads (not filtered by assignment)
- Access to delete functionality
- Access to all dashboard stats

### Sales User
- Can view and update only their assigned leads
- Cannot create or delete leads
- Cannot reassign leads
- Dashboard shows only their leads' stats

---

## 🚀 Deployment

### Render (Backend)
1. Create a new **Web Service** on [render.com](https://render.com)
2. Connect your GitHub repository
3. Set:
   - **Root Directory:** `backend`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
4. Add all environment variables from `.env.example`
5. Set `MONGODB_URI` to your MongoDB Atlas connection string

### Vercel (Frontend)
1. Import your repository on [vercel.com](https://vercel.com)
2. Set:
   - **Framework Preset:** Vite
   - **Root Directory:** `frontend`
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
3. Add environment variable:
   - `VITE_API_BASE_URL` = your Render backend URL + `/api`

### MongoDB Atlas
1. Create a free cluster at [cloud.mongodb.com](https://cloud.mongodb.com)
2. Create a database user
3. Whitelist `0.0.0.0/0` (or your Render IP)
4. Copy the connection string to `MONGODB_URI`

---

## 🎬 Demo Walkthrough Script

> Use this script for your Loom video recording.

**[0:00]** "Welcome to GigFlow – a Smart Leads Dashboard built with the MERN stack and TypeScript."

**[0:10]** Show the login page → demo credentials card → log in as Admin.

**[0:25]** Dashboard overview → stat cards (total, qualified, in progress, lost) → status/source bars → recent leads list.

**[0:45]** Navigate to Leads → show the full leads table with pagination.

**[1:00]** Demonstrate filtering: select Status = "Qualified" → Source = "Instagram" → watch table update.

**[1:15]** Demonstrate debounced search: type "Rahul" → notice the 400ms delay before API fires.

**[1:30]** Click Export CSV → show the downloaded file.

**[1:45]** Admin: click "Add Lead" → fill the form → create → lead appears in table.

**[2:00]** Click edit (pencil) on a lead → update status → save.

**[2:15]** Click delete → confirmation modal → confirm deletion.

**[2:30]** Log out → log in as Sarah (sales user) → show restricted view (no delete, only assigned leads).

**[2:45]** Toggle dark mode in top-right → show UI in dark mode.

**[3:00]** Show Docker setup: `docker compose up --build` command.

**[3:15]** "GigFlow is production-ready with TypeScript, modular architecture, RBAC, and clean code. Thank you!"

---

## 📝 License

MIT © GigFlow 2024
